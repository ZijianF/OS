#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include "util.h"

#define CMDLINE_MAX 512
#define TOKEN_MAX 32
#define ARGUMENT_MAX 16
#define MAX_PROGRAM 4
#define ALPHABET 26

int main(void)
{
        char cmd[CMDLINE_MAX];
        char **var;
        var = calloc(ALPHABET, sizeof(char *));
        for (int i = 0; i < ALPHABET; i++)
        {
                var[i] = calloc(TOKEN_MAX + 1, sizeof(char));
        }

        while (1)
        {
                //each loop is readyto execute one line of commands
                char *nl;

                /* Print prompt */
                printf("sshell@ucd$ ");
                fflush(stdout);

                /* Get command line */
                fgets(cmd, CMDLINE_MAX, stdin);

                char cmdprint[CMDLINE_MAX];
                memset(cmdprint, '\0', CMDLINE_MAX);
                strncpy(cmdprint, cmd, strlen(cmd));
                strtok(cmdprint, "\n");

                /* Print command line if stdin is not provided by terminal */
                if (!isatty(STDIN_FILENO))
                {
                        printf("%s", cmd);
                        fflush(stdout);
                }

                /* Remove trailing newline from command line */
                nl = strchr(cmd, '\n');
                if (nl)
                        *nl = '\0';

                char ***splittedarguments;
                splittedarguments = (char ***)calloc(1, sizeof(char **));
                size_t argcounts;
                argcounts = PickCommand(cmd, splittedarguments);
                if (argcounts == 0)
                {
                        splittedarguments = NULL;
                        continue;
                }
                if (!strcmp((*splittedarguments)[0], "exit"))
                {
                        /*exit should never fail*/
                        fprintf(stderr, "Bye...\n");
                        fprintf(stderr, "+ completed '%s' [0]\n", cmdprint);
                        FreePointertoArrayofString(splittedarguments, argcounts);
                        break;
                }
                if (!strcmp((*splittedarguments)[0], "cd"))
                {
                        /*cd will return 1 if it fails to cd into the directory*/
                        bool fail = cd((*splittedarguments)[1]);
                        if (fail)
                        {
                                fprintf(stderr, "Error: cannot cd into directory\n");
                        }
                        fprintf(stderr, "+ completed '%s' [%d]\n", cmdprint, fail);
                        continue;
                }
                if (!strcmp((*splittedarguments)[0], "pwd"))
                {
                        /*pwd should never fail*/
                        pwd();
                        fprintf(stderr, "+ completed '%s' [0]\n", cmdprint);
                        continue;
                }

                program prgms[MAX_PROGRAM];

                // initialize all prgms
                for (int i = 0; i < MAX_PROGRAM; i++)
                {
                        prgms[i].active = false;
                        prgms[i].pipein = false;
                        prgms[i].pipeout = false;
                        prgms[i].redirec = false;
                        prgms[i].args = calloc(1, sizeof(char *));
                        prgms[i].argcounts = 0;
                }

                bool new_command = 1;
                size_t p_count = 0;
                int pipe_count = 0;
                bool error = false;
                for (size_t i = 0; i < argcounts; i++)
                {

                        if (new_command) // A new program is detected
                        {
                                if ((!strcmp((*splittedarguments)[i], "|") || (!strcmp((*splittedarguments)[i], ">"))))
                                {
                                        fprintf(stderr, "Error: missing command\n");
                                        error = true;
                                        break;
                                }
                                if (!strcmp((*splittedarguments)[i], "$"))
                                {
                                        if (strlen((*splittedarguments)[i + 1]) != 1)
                                        {
                                                /*Error if the next token is not a single char*/
                                                fprintf(stderr, "Error: 1invalid variable name\n");
                                                error = true;
                                                break;
                                        }
                                        int index = (*splittedarguments)[i + 1][0] - 97;
                                        if (index < 0 || index >= ALPHABET)
                                        {
                                                /*Error if the next token is between a-z*/
                                                fprintf(stderr, "Error: invalid variable name\n");
                                                error = true;
                                                break;
                                        }
                                        if (i == argcounts - 1)
                                        {
                                                /*Error if the current token is the last token*/
                                                fprintf(stderr, "Error: invalid variable name\n");
                                                error = true;
                                                break;
                                        }
                                        /*Allocate new memory block to store the variable's value
                                        so it does not get freed when freeing all pointers in the programs*/
                                        char *temp;
                                        temp = calloc(strlen(var[index]) + 1, sizeof(char));
                                        strcpy(temp, var[index]);
                                        prgms[p_count].args = realloc(prgms[p_count].args, (prgms[p_count].argcounts + 1) * sizeof(char *));
                                        prgms[p_count].args[prgms[p_count].argcounts] = temp;
                                        prgms[p_count].argcounts++;
                                        i++;
                                        prgms[p_count].active = true;
                                        new_command = false;
                                        continue;
                                }
                                prgms[p_count].args = realloc(prgms[p_count].args, (prgms[p_count].argcounts + 1) * sizeof(char *));
                                prgms[p_count].args[(prgms[p_count].argcounts)] = NULL;
                                //memcpy
                                size_t l = strlen((*splittedarguments)[i]);

                                prgms[p_count].args[(prgms[p_count].argcounts)] = calloc(l + 1, sizeof(char));

                                memcpy(prgms[p_count].args[(prgms[p_count].argcounts)], (*splittedarguments)[i], l);
                                prgms[p_count]
                                    .active = true;
                                new_command = false;
                                prgms[p_count].argcounts++;
                                continue;
                        }
                        if (!strcmp((*splittedarguments)[i], "|"))
                        {
                                if (prgms[p_count].redirec)
                                {
                                        /*Error if the previous program redirects its output into
                                        a file*/
                                        fprintf(stderr, "Error: mislocated output redirection\n");
                                        error = true;
                                        break;
                                }
                                prgms[p_count].pipeout = true;
                                prgms[p_count + 1].pipein = true;
                                new_command = true;
                                p_count++;
                                pipe_count++;
                                if (i == argcounts - 1)
                                {
                                        /*Error if there is no command after the '|'*/
                                        fprintf(stderr, "Error: missing command\n");
                                        error = true;
                                        break;
                                }
                                continue;
                        }
                        else if (!strcmp((*splittedarguments)[i], ">"))
                        {
                                if (i == argcounts - 1)
                                {
                                        /*Error if there is no command after the '>'*/
                                        fprintf(stderr, "Error: no output file\n");
                                        error = true;
                                        break;
                                }
                                if (!strcmp((*splittedarguments)[i + 1], "|"))
                                {
                                        /*Error if the command after it is a '|'*/
                                        fprintf(stderr, "Error: no output file\n");
                                        error = true;
                                        break;
                                }

                                // memcpy
                                size_t flength = strlen((*splittedarguments)[i + 1]);
                                prgms[p_count].redirec = true;
                                prgms[p_count].filename = calloc(flength + 1, sizeof(char));
                                memcpy(prgms[p_count].filename, (*splittedarguments)[i + 1], flength);
                                i++;
                                int fp;
                                fp = open(prgms[p_count].filename, O_TRUNC | O_WRONLY | O_CREAT, 0644);
                                if (fp != 0)
                                {
                                        if (errno == EACCES)
                                        {
                                                fprintf(stderr, "Error: cannot open output file\n");
                                                close(fp);
                                                error = true;
                                                break;
                                        }
                                }
                                close(fp);
                                continue;
                        }
                        else if (!strcmp((*splittedarguments)[i], "$"))
                        {
                                if (strlen((*splittedarguments)[i + 1]) != 1)
                                {
                                        fprintf(stderr, "Error: 1invalid variable name\n");
                                        error = true;
                                        break;
                                }
                                int index = (*splittedarguments)[i + 1][0] - 97;
                                if (index < 0 || index >= ALPHABET)
                                {
                                        fprintf(stderr, "Error: invalid variable name\n");
                                        error = true;
                                        break;
                                }
                                if (i == argcounts - 1)
                                {
                                        fprintf(stderr, "Error: invalid variable name\n");
                                        error = true;
                                        break;
                                }
                                char *temp;
                                temp = calloc(strlen(var[index]) + 1, sizeof(char));
                                strcpy(temp, var[index]);
                                prgms[p_count].args = realloc(prgms[p_count].args, (prgms[p_count].argcounts + 1) * sizeof(char *));
                                prgms[p_count].args[prgms[p_count].argcounts] = temp;
                                prgms[p_count].argcounts++;
                                i++;
                                continue;
                        }
                        prgms[p_count].args = realloc(prgms[p_count].args, (prgms[p_count].argcounts + 1) * sizeof(char *));
                        prgms[p_count].args[(prgms[p_count].argcounts)] = NULL;
                        //memcpy
                        size_t l = strlen((*splittedarguments)[i]);
                        prgms[p_count].args[(prgms[p_count].argcounts)] = calloc(l + 1, sizeof(char));

                        memcpy(prgms[p_count].args[(prgms[p_count].argcounts)], (*splittedarguments)[i], l);

                        prgms[p_count].argcounts++;
                        if (prgms[p_count].argcounts > 16)
                        {
                                fprintf(stderr, "Error: too many process arguments\n");
                                error = true;
                                break;
                        }
                }
                if (error)
                {
                        free_program(prgms);
                        continue;
                }

                if (!strcmp(prgms[0].args[0], "set"))
                {
                        if (prgms[0].argcounts < 2)
                        {
                                /*Error when "set" is the only command*/
                                fprintf(stderr, "Error: invalid variable name\n");
                                free_program(prgms);
                                // FreePointertoArrayofString(splittedarguments, argcounts);
                                // splittedarguments = NULL;
                                continue;
                        }

                        int index = prgms[0].args[1][0] - 97;
                        if (index < 0 || index >= ALPHABET)
                        {
                                /*Error if the variable is not a-z*/
                                fprintf(stderr, "Error: invalid variable name\n");
                                free_program(prgms);
                                // FreePointertoArrayofString(splittedarguments, argcounts);
                                // splittedarguments = NULL;
                                continue;
                        }
                        if (strlen(prgms[0].args[1]) > 1)
                        {
                                /*Error if the variable is longer than one letter*/
                                fprintf(stderr, "Error: invalid variable name\n");
                                fprintf(stderr, "+ completed '%s' [1]\n", cmdprint);
                                free_program(prgms);
                                // FreePointertoArrayofString(splittedarguments, argcounts);
                                // splittedarguments = NULL;
                                continue;
                        }
                        if (prgms[0].argcounts == 2)
                        {
                                var[index] = "";
                                fprintf(stderr, "+ completed '%s' [0]\n", cmdprint);
                                free_program(prgms);
                                // FreePointertoArrayofString(splittedarguments, argcounts);
                                // splittedarguments = NULL;
                                continue;
                        }
                        char *temp;
                        temp = calloc(strlen(var[index]) + 1, sizeof(char));
                        free(var[index]);
                        strcpy(temp, prgms[0].args[2]);
                        var[index] = temp;
                        fprintf(stderr, "+ completed '%s' [0]\n", cmdprint);
                        prgms[0].args = realloc(prgms[0].args, (prgms[0].argcounts + 1) * sizeof(char *));
                        free_program(prgms);
                        FreePointertoArrayofString(splittedarguments, argcounts);
                        //splittedarguments = NULL;
                        continue;
                }

                for (int i = 0; i < MAX_PROGRAM; i++) //adding NULL at the end so execvp can work properly
                {
                        if (prgms[i].active)
                        {
                                prgms[i].args = realloc(prgms[i].args, (prgms[i].argcounts + 1) * sizeof(char *));
                                prgms[i].args[prgms[i].argcounts] = NULL;
                        }
                }
                //reference from https://stackoverflow.com/questions/916900/having-trouble-with-fork-pipe-dup2-and-exec-in-c/

                int fd[pipe_count][2];
                int status;
                int stats[pipe_count + 1];
                for (int i = 0; i < pipe_count + 1; i++)
                {
                        if (prgms[i + 1].active)
                        {
                                pipe(fd[i]);
                        }
                        pid_t pid = fork();
                        if (pid == 0)
                        { //this is a child
                                if (i > 0)
                                {
                                        dup2(fd[i - 1][0], STDIN_FILENO);
                                        close(fd[i - 1][0]);
                                        close(fd[i - 1][1]);
                                }
                                if (prgms[i + 1].active && i != pipe_count)
                                {
                                        close(fd[i][0]);
                                        dup2(fd[i][1], STDOUT_FILENO);
                                        close(fd[i][1]);
                                }
                                if (prgms[i].redirec)
                                {
                                        int fp;
                                        fp = open(prgms[i].filename, O_WRONLY | O_CREAT, 0644);
                                        dup2(fp, STDOUT_FILENO);
                                        close(fp);
                                }
                                execvp(prgms[i].args[0], prgms[i].args);
                                fprintf(stderr, "Error: command not found\n");
                                exit(1);
                        }
                        else if (pid < 0)
                        {
                                perror("fork failed");
                                exit(1);
                        }
                        else //parent
                        {
                                if (i > 0)
                                {
                                        close(fd[i - 1][0]);
                                        close(fd[i - 1][1]);
                                }
                                wait(&status);
                                stats[i] = WEXITSTATUS(status);
                        }
                }
                fprintf(stderr, "+ completed '%s' ", cmdprint);
                for (int i = 0; i < pipe_count + 1; i++)
                {
                        fprintf(stderr, "[%d]", stats[i]);
                }
                fprintf(stderr, "\n");
                free_program(prgms);
                if (splittedarguments)
                {
                        FreePointertoArrayofString(splittedarguments, argcounts);
                }
        }
        for (int j = 0; j < ALPHABET; j++)
        {
                free(var[j]);
        }
        free(var);

        return EXIT_SUCCESS;
}

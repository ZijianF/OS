#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdbool.h>
#include <sys/wait.h>
#define MAX_PROGRAM 4

typedef struct programs{
        bool active;
        bool redirec;
        bool pipein;
        bool pipeout;
        char** args;
        char* filename;
        size_t argcounts;
}program;

size_t PickCommand(char argv[], char***splittedarguments);

int cd(char* path);

int pwd();

void FreePointertoArrayofString(char ***pointer, size_t n);
void FreeArrayofString(char**pointer, size_t n);
void FreeArrayofNum(size_t **pointer, size_t n);
void free_program(program prgms[MAX_PROGRAM]);
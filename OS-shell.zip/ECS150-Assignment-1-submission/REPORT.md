# A Simple Shell
| ·---------------------------------------------------------------------------· |
| ----------------------------------------------------------------------------- |
## Commands and command line  
---
        When a shell takes in a string of commands it needs to identify a 
    few things:
    1.Which part of the string belongs to an executable. 
    2.Does the current pattern of the string cause misonceptions or errors.
    3.Can the arguments (including the output redirection)  be taken and run.

        Num 2,3 will be specified later, but first we need to get individual 
    commands.

        For Num1, we could naively assume that each token(space separated) 
    is an  argument. But it could be something like "echo1|echo>out.txt" ,
    which is  only located in the first token, we need to go char by char.
    For that reason 3 dynamic memory allocation loop was created. The first one 
    is aimed for storing the tokens and the second for separting and storing 
    the alphabetical words and '|', '>' in this assignment, and last is 
    for copying to passed-in refernce. One could argue we could let first and
    second loop merge, but for a few more lines with debuging purpose is worth
    it.
---
## Builtin commands
---
    cd: There are two situations for cd:
        1.  The received address is an absolute path to the destination,
        then we can use chdir() to change.
        2.  The received address is a relative address, then we need,
        then we need to get the current repository's adress and 
        append the received relative address onto this address.
    pwd:    pwd is achieved by getcwd() function;
    exit:   exit simply terminates the program by ending the while loop;

## Output redirection
---
    For output redirection, we first seperate '>' from all given commands,
    then perform error checking when > is detected while adding arguments
    into the program struct. If arguments are valid, then the coresponding
    program will record the file's path. While executing this program,
    it will replace its STDOUT with the file's descripter.
## Piping
---
    reference: https://stackoverflow.com/questions/916900/having-trouble-with-fork-pipe-dup2-and-exec-in-c/
    Piping is achieve by multiple steps of operation:
        step1:  count how many pipes are there, X.
        step2:  create x pipes. (We believe it can also be achieve by
        recycling two pipes, but since this program will only have a
        maximum of 3 pipes, it would not hurt much). By puting them in
        a array, we can easily manipulate and track the pipes via index
        during the execution loop;
        step3:  fork() is used every time before executing a command
        When executing two programs that are connected with pipe,
        the first program's child's STDOUT will be replaced with the pipe,
        the parent will go on and execute the next program in line, and its
        child will execute the second command, with its STDIN being replaced
        the previous pipe. At the same time, it will detect if there is a
        pipe between itself and the next command.
## Error management
---
    Error management strategies follow closely to the prompts' standard.
    Parsing errors detections happen during parsing, 
    and launching errors are detected during executing commands.
## Extra features
---
    set: The set function is achieve with a few steps:
        step1:  creating a "dictionary" in the global scope, where it
        can be access anytime during runtime.
        step2:  parse commands in a way such that '$' can be recognized
        by itself.
        step3:  When detecting the "set" command, if the command is valid,
        update the variable's "value" in the dictionary.
        step4:  When detecting the '$' during parsing, if the command is 
        valid, replace the variable with its respected value from the
        dictionary.
### Testing
---
    Used provided test.sh on linux local environment to check simple cases.
    Afterwards, scp the files to csif and re-tested there.
    Used Valgrind to find memory leakage.
---
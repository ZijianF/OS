#include <unistd.h>
#include <errno.h>
#include "util.h"

#define TOKEN_MAX 32
#define BUFFER_SIZE 128

size_t PickCommand(char argv[], char ***splittedarguments)
{
    if (strlen(argv) == 0)
    {
        //Free splittedarguments at its local scope

        free(splittedarguments);

        fprintf(stdout, "Nullified splittedargs\n");

        return 0;
    }

    char **tokenlist = NULL;

    char *token = NULL;
    size_t tokenlength = 0;
    //allocated memory array needs to be tracked
    size_t tokenlistlength = 0;
    token = strtok(argv, " ");
    if (strlen(argv) == 0)
        return 0;

    //strip the front and end spaces and store the tokens
    for (size_t i = 0; token != NULL; i++)
    {
        tokenlength = strlen(token);

        tokenlist = (char **)realloc(tokenlist, (i + 1) * sizeof(char *));

        tokenlist[i] = (char *)calloc((tokenlength + 1), sizeof(char));
        memset(tokenlist[i], '\0', tokenlength + 1);
        strncpy(tokenlist[i], token, strlen(token));
        tokenlistlength++;
        token = strtok(NULL, " ");
    }
    size_t finallistlength = 0;
    size_t index = 0;
    size_t alphabet = 0;
    size_t tokenlimit = 32;
    char **finallist = NULL;

    //The loop goes through the characters in each token
    //it accumulates the alphabet and store them when a
    //sign is hit.
    for (size_t i = 0; i < tokenlistlength; i++)
    {
        //preping token

        tokenlength = strlen(tokenlist[i]);
        free(token);
        token = (char *)malloc(tokenlength * sizeof(char));

        memset(token, '\0', tokenlength);
        strncpy(token, tokenlist[i], tokenlength);

        char accu[tokenlimit];
        memset(accu, '\0', sizeof(accu));
        for (size_t i = 0; i < tokenlimit; i++)
        {
            // printf("%lu\n", i);
            if (i >= tokenlength)
                break;
            char c = token[i];
            switch (c)
            {
            case '$':
                if (strlen(accu) != 0)
                {

                    finallist = (char **)realloc(finallist, (++index) * sizeof(char *));
                    finallist[index - 1] = (char *)malloc((strlen(accu) + 1) * sizeof(char));
                    memset(finallist[index - 1], '\0', strlen(accu) + 1);
                    strncpy(finallist[index - 1], accu, strlen(accu));
                    finallistlength++;
                    memset(accu, '\0', tokenlimit);
                    alphabet = 0;
                }
                finallist = (char **)realloc(finallist, (++index) * sizeof(char *));
                finallist[index - 1] = (char *)malloc(sizeof(char) + 1);
                memset(finallist[index - 1], '\0', 2);
                finallist[index - 1][0] = '$';
                finallistlength++;
                break;
            case '>':
                if (strlen(accu) != 0)
                {

                    finallist = (char **)realloc(finallist, (++index) * sizeof(char *));
                    finallist[index - 1] = (char *)malloc((strlen(accu) + 1) * sizeof(char));
                    memset(finallist[index - 1], '\0', strlen(accu) + 1);
                    strncpy(finallist[index - 1], accu, strlen(accu));
                    finallistlength++;
                    memset(accu, '\0', tokenlimit);
                    alphabet = 0;
                }
                finallist = (char **)realloc(finallist, (++index) * sizeof(char *));
                finallist[index - 1] = (char *)malloc(sizeof(char) + 1);
                memset(finallist[index - 1], '\0', 2);
                finallist[index - 1][0] = '>';
                finallistlength++;
                break;
            case '|':

                if (strlen(accu) != 0)
                {

                    finallist = (char **)realloc(finallist, (++index) * sizeof(char *));
                    finallist[index - 1] = (char *)malloc((strlen(accu) + 1) * sizeof(char));
                    memset(finallist[index - 1], '\0', strlen(accu) + 1);
                    strncpy(finallist[index - 1], accu, strlen(accu));
                    finallistlength++;
                    memset(accu, '\0', tokenlimit);
                    alphabet = 0;
                }
                finallist = (char **)realloc(finallist, (++index) * sizeof(char *));
                finallist[index - 1] = (char *)malloc(sizeof(char) + 1);
                memset(finallist[index - 1], '\0', 2);
                finallist[index - 1][0] = '|';
                finallistlength++;
                break;
            default:
                accu[alphabet] = token[i];
                alphabet++;
                break;
            }
        }
        if (alphabet != 0)
        {
            //fprintf(stdout, "acculen : %lu\n", strlen(accu));
            finallist = (char **)realloc(finallist, (++index) * sizeof(*finallist));
            finallist[index - 1] = (char *)malloc((strlen(accu) + 1) * sizeof(char));
            memset(finallist[index - 1], '\0', strlen(accu) + 1);

            strncpy(finallist[index - 1], accu, alphabet);
            finallistlength++;
            // fprintf(stdout, "%s\n", finallist[index - 1]);
            alphabet = 0;
        }
    }

    free(token);

    FreeArrayofString(tokenlist, tokenlistlength);

    //Copy the alphbetical words and sign separated tokens to the passed-reference
    *splittedarguments = (char **)calloc(finallistlength, sizeof(char *));
    for (size_t i = 0; i < finallistlength; i++)
    {
        (*splittedarguments)[i] = (char *)calloc(strlen(finallist[i]) + 1, sizeof(char));
        memcpy((*splittedarguments)[i], finallist[i], strlen(finallist[i]));
        free(finallist[i]);
    }
    free(finallist);

    return finallistlength;
}

void FreePointertoArrayofString(char ***pointer, size_t n)
{
    for (size_t i = 0; i < n; i++)
    {
        free((*pointer)[i]);
    }
    free(*pointer);
    free(pointer);
}

void FreeArrayofString(char **pointer, size_t n)
{
    for (size_t i = 0; i < n; i++)
    {
        free(((pointer)[i]));
    }
    free(pointer);
}

void FreeArrayofNum(size_t **pointer, size_t n)
{
    for (size_t i = 0; i < n; i++)
    {
        free(((pointer)[i]));
    }
    free(pointer);
}

int cd(char *path)
{
    char address[TOKEN_MAX];
    strcpy(address, path);
    if (address[0] != '/')
    {//if the received address is not an absolute path
        char cur_path[BUFFER_SIZE];
        getcwd(cur_path, sizeof(cur_path));
        strcat(cur_path, "/");
        strcat(cur_path, address);
        int status = chdir(cur_path);
        if(status == -1){
            return 1;
        }
    }
    else
    {//the received address is an absolute path
        int status = chdir(address);
        if(status == -1){
            return 1;
        }
    }
    return 0;
}

int pwd()
{
    char address[BUFFER_SIZE];
    getcwd(address, sizeof(address));
    fprintf(stdout, "%s\n", address);
    return 0;
}

void free_program(program prgms[MAX_PROGRAM]){
        for(int i = 0; i < MAX_PROGRAM; i++){
                for(size_t j = 0; j < prgms[i].argcounts; j++){
                        free(prgms[i].args[j]);
                }
                free(prgms[i].args);
                if(prgms[i].redirec){
                    free(prgms[i].filename);
                }
                
        }
}

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#include "disk.h"
#include "fs.h"

#define BLOCK_SIZE 4096
#define FAT_EOC 0xFFFF
#define MAX_DES 32

typedef struct
{
	int32_t signature[2];
	int16_t bcount;
	int16_t RD_index;
	int16_t DB_start_index;
	int16_t DB_count;
	int8_t FAT_count;
	int8_t Padding[BLOCK_SIZE - 17];
} __attribute__((packed)) super_block;

typedef struct
{
	uint8_t filename[16];
	uint32_t f_size;
	uint16_t index;
	int16_t padding[5];
} __attribute__((packed)) entry;

struct metadata
{
	super_block s_block;
	uint16_t *FAT;
	entry R_directory[FS_FILE_MAX_COUNT];
	int mounted;
	size_t used_FAT_count;
	size_t used_entry;
};

typedef struct
{
	int occupied;
	entry file;
	size_t size;
	u_int64_t inc;
	size_t RD_index;

} fd;

//global data ----------------->
size_t des_count = 0;
fd descriptors[MAX_DES];
struct metadata m_data;
//global data ends  ----------------->

//check if name is valid
int fs_name_check(const char *filename)
{
	if (!filename)
	{
		return -1;
	}

	size_t name_length = strlen(filename) + 1;
	if (name_length > FS_FILENAME_LEN)
	{
		return -1;
	}
	for (int i = 0; i < FS_FILENAME_LEN; i++)
	{
		if (filename[i] == '\0')
		{
			break;
		}
		if (i == 15)
		{
			return -1;
		}
	}
	return 1;
}

//find if name exist and return existing index
int fs_name_find(const char *filename)
{
	int file_index = -1;
	for (int i = 0; i < FS_FILE_MAX_COUNT; i++)
	{
		if (strcmp((char *)m_data.R_directory[i].filename, filename) == 0)
		{
			//break if the file is found;
			file_index = i;
			break;
		}
	}
	return file_index;
}

int fs_mount(const char *diskname)
{
	if (block_disk_open(diskname) < 0)
	{
		return -1;
	}

	block_read(0, &m_data.s_block);

	if (strcmp((char *)m_data.s_block.signature, "ECS150FS") == 0)
	{
		return -1;
	}
	//size_t total_block_count = m_data.s_block.DB_count + 1 + m_data.s_block.FAT_count + 1;
	if (block_disk_count() != m_data.s_block.bcount)
	{
		return -1;
	}

	uint16_t temp_block[BLOCK_SIZE / 2];
	m_data.FAT = calloc(m_data.s_block.FAT_count * BLOCK_SIZE / 2, sizeof(uint16_t));
	for (int i = 1; i <= m_data.s_block.FAT_count; i++)
	{
		block_read(i, &temp_block);
		memcpy(&m_data.FAT[(i - 1) * (BLOCK_SIZE / 2)], temp_block, BLOCK_SIZE);
	}

	//read the root directory
	block_read(m_data.s_block.RD_index, &m_data.R_directory);
	m_data.mounted = 1;

	size_t temp_count = 0;
	for (int i = 0; i < m_data.s_block.FAT_count * BLOCK_SIZE / 2; i++)
	{
		if (m_data.FAT[i])
		{
			temp_count++;
		}
	}
	m_data.used_FAT_count = temp_count;
	temp_count = 0;
	for (int i = 0; i < FS_FILE_MAX_COUNT; i++)
	{
		if ((char)m_data.R_directory[i].filename[0] != '\0')
		{
			temp_count++;
		}
	}
	m_data.used_entry = temp_count;

	//init empty descriptors
	for (size_t i = 0; i < MAX_DES; i++)
	{
		descriptors[i].occupied = -1;
	}
	return 0;
}

int fs_umount(void)
{

	if (!m_data.mounted)
	{
		return -1;
	}
	if (des_count != 0)
	{
		return -1;
	}
	block_write(0, &m_data.s_block);

	//buffer for handling partial access
	uint16_t temp_block[BLOCK_SIZE / 2];

	for (int i = 1; i < m_data.s_block.FAT_count; i++)
	{
		memcpy(temp_block, &m_data.FAT[(i - 1) * (BLOCK_SIZE / 2)], BLOCK_SIZE);
		block_write(i, &temp_block);
	}
	int remaining_bytes = (m_data.s_block.DB_count * 2) % BLOCK_SIZE;
	if (remaining_bytes == 0)
	{
		remaining_bytes = BLOCK_SIZE;
	}
	/* If FAT occupies only one block, then need to start reading from 0 */
	size_t cpy_index = m_data.s_block.FAT_count * (BLOCK_SIZE / 2);
	if (m_data.s_block.FAT_count == 1)
	{
		cpy_index = 0;
	}
	memcpy(temp_block, &m_data.FAT[cpy_index], remaining_bytes);
	block_write(m_data.s_block.FAT_count, &temp_block);

	block_write(m_data.s_block.RD_index, &m_data.R_directory);

	free(m_data.FAT);

	if (block_disk_close() < 0)
		return -1;
	m_data.mounted = 0;
	return 0;
}

int fs_info(void)
{
	if (!m_data.mounted)
	{
		return -1;
	}

	printf("FS Info:\n");
	printf("total_blk_count=%d\n", m_data.s_block.bcount);
	printf("fat_blk_count=%d\n", m_data.s_block.FAT_count);
	printf("rdir_blk=%d\n", m_data.s_block.RD_index);
	printf("data_blk=%d\n", m_data.s_block.DB_start_index);
	printf("data_blk_count=%d\n", m_data.s_block.DB_count);
	printf("fat_free_ratio=%ld/%d\n", m_data.s_block.DB_count - m_data.used_FAT_count, m_data.s_block.DB_count);
	printf("rdir_free_ratio=%ld/%d\n", FS_FILE_MAX_COUNT - m_data.used_entry, FS_FILE_MAX_COUNT);
	return 0;
}

int fs_create(const char *filename)
{
	if (!m_data.mounted)
	{
		return -1;
	}

	if (fs_name_check(filename) < 0)
		return -1;
	int empty_entry = -1;
	for (size_t i = 0; i < FS_FILE_MAX_COUNT; i++)
	{
		/*Test if the entry is empty*/
		if (m_data.R_directory[i].filename[0] == '\0')
		{
			//remember the last empty entry
			if (empty_entry == -1)
			{
				empty_entry = i;
			}
		}
		else if (strcmp((char *)m_data.R_directory[i].filename, filename) == 0)
		{
			//error if file with same name already exists
			return -1;
		}
	}
	if (empty_entry == -1)
	{
		//if the value remains -1, means there is no more empty entry
		return -1;
	}
	strcpy((char *)m_data.R_directory[empty_entry].filename, filename);
	m_data.R_directory[empty_entry].f_size = 0;
	m_data.R_directory[empty_entry].index = FAT_EOC;
	m_data.used_entry++;
	return 0;
}

int fs_delete(const char *filename)
{
	if (!m_data.mounted)
	{
		return -1;
	}

	if (fs_name_check(filename) < 0)
	{
		return -1;
	}

	/* Error when the file is still opened */
	for (int i = 0; i < MAX_DES; i++)
	{
		if (strcmp((char *)descriptors[i].file.filename, filename) == 0)
		{
			if (descriptors[i].occupied > 0)
			{
				return -1;
			}
		}
	}

	int file_index = fs_name_find(filename);
	if (file_index < 0)
	{
		return -1;
	}

	/* reset the entry's data */
	m_data.R_directory[file_index].filename[0] = '\0';
	m_data.R_directory[file_index].f_size = 0;
	m_data.used_entry--;
	size_t current_index = m_data.R_directory[file_index].index;
	while (current_index != FAT_EOC)
	{

		int temp = current_index;
		current_index = m_data.FAT[current_index];
		m_data.FAT[temp] = 0;
		m_data.used_FAT_count--;
	}
	m_data.used_FAT_count--;
	return 0;
}

int fs_ls(void)
{
	if (!m_data.mounted)
	{
		return -1;
	}
	printf("FS Ls:\n");
	for (int i = 0; i < FS_FILE_MAX_COUNT; i++)
	{
		if (m_data.R_directory[i].filename[0] != '\0')
		{
			printf("file: %s, ", m_data.R_directory[i].filename);
			printf("size: %d, ", m_data.R_directory[i].f_size);
			printf("data_blk: %d\n", m_data.R_directory[i].index);
		}
	}
	return 0;
}

//open returns a file descriptor for every open even for the same file
int fs_open(const char *filename)
{
	if (!m_data.mounted)
	{
		return -1;
	}

	if (fs_name_check(filename) < 0)
	{
		return -1;
	}

	int file_index = fs_name_find(filename);
	if (file_index < 0)
		return -1;
	if (des_count + 1 > MAX_DES)
	{
		return -1;
	}

	//find the next empty space;
	int file_des_index = -1;
	for (int i = 0; i < MAX_DES; i++)
	{
		if (descriptors[i].occupied < 0)
		{
			file_des_index = i;
			break;
		}
	}
	descriptors[file_des_index].file = m_data.R_directory[file_index];
	descriptors[file_des_index].occupied = 1;
	descriptors[file_des_index].size = m_data.R_directory[file_index].f_size;
	descriptors[file_des_index].inc = 0;
	descriptors[file_des_index].RD_index = file_index;
	des_count++;
	return file_des_index;
}

int fs_close(int fd)
{

	if (!m_data.mounted)
	{
		return -1;
	}

	//check if fd is valid and occupied(not closed before)
	if (fd < 0 || fd >= MAX_DES)
		return -1;
	if (descriptors[fd].occupied < 0)
		return -1;

	descriptors[fd].occupied = -1;
	des_count--;
	return fd;
}

int fs_stat(int fd)
{

	if (!m_data.mounted)
	{
		return -1;
	}

	//check if fd is valid and available
	if (fd < 0 || fd >= MAX_DES)
		return -1;

	if (descriptors[fd].occupied > 0)
	{
		return descriptors[fd].size;
	}

	return -1;
}

//updates the wraper offset
int fs_lseek(int fd, size_t offset)
{

	if (!m_data.mounted)
	{
		return -1;
	}
	if (fd < 0 || fd >= MAX_DES)
		return -1;

	if (descriptors[fd].occupied > 0 && descriptors[fd].inc <= descriptors[fd].size)
	{
		descriptors[fd].inc = offset;
		return 0;
	}
	return -1;
}

size_t blocks_to_skip(int fd)
{
	/* Calculate how many blocks to skip since the begining of the file */
	size_t skip_count = descriptors[fd].inc / BLOCK_SIZE;
	return skip_count;
}

size_t find_first_empty_block(int start)
{
	/* Find the next empty block */
	size_t first_empty_block = 0;
	for (int i = start; i < m_data.s_block.DB_count; i++)
	{
		if (m_data.FAT[i] == 0)
		{
			first_empty_block = i;
			return first_empty_block;
		}
	}
	return -1;
}

void update_fd(int fd, int diff, int size_change)
{
	descriptors[fd].size += size_change;
	descriptors[fd].inc += diff;
	descriptors[fd].file.f_size += size_change;
}

void update_RD(int fd)
{
	size_t index = descriptors[fd].RD_index;
	m_data.R_directory[index].f_size = descriptors[fd].size;
	m_data.R_directory[index].index = descriptors[fd].file.index;
}

int size_diff(int fd, size_t bytes)
{
	/* Calculate the how many bytes will be changed after writing */
	int diff = descriptors[fd].inc + bytes - descriptors[fd].size;
	if (diff < 0)
	{
		diff = 0;
	}
	return diff;
}

int fs_write(int fd, void *buf, size_t count)
{

	if (!m_data.mounted)
	{
		return -1;
	}
	if (fd < 0 || fd >= MAX_DES)
	{
		return -1;
	}
	if (!buf)
	{
		return -1;
	}
	if (count == 0)
	{
		return 0;
	}

	size_t bytes_written = 0;
	/* get the start index to read with current offset */
	size_t skip_count = blocks_to_skip(fd);
	//calculate writable space in the file's last DB
	size_t space_in_last_block = descriptors[fd].size;
	while (space_in_last_block > BLOCK_SIZE)
	{
		space_in_last_block -= BLOCK_SIZE;
	}
	size_t offset = descriptors[fd].inc % BLOCK_SIZE;
	space_in_last_block = BLOCK_SIZE - space_in_last_block;

	/* available space in the disk = total space - 
	# of used DB * block_size + remaining space in the file's last block */
	size_t available_space = (m_data.s_block.DB_count * BLOCK_SIZE) - (m_data.used_FAT_count * BLOCK_SIZE) + space_in_last_block;

	/* 0 bytes is written is no available space on the disk */
	if (available_space == 0)
	{
		return bytes_written;
	}

	bytes_written = count;
	if (count > available_space)
	{
		bytes_written = available_space;
	}

	size_t current_FAT_index = descriptors[fd].file.index;
	while (skip_count != 0)
	{
		current_FAT_index = m_data.FAT[current_FAT_index];
		skip_count--;
	}

	int empty_file = 0;
	if (current_FAT_index == FAT_EOC)
	{
		empty_file = 1;
		descriptors[fd].file.index = find_first_empty_block(0);
	}

	/*Buffer blocks for storing content that need to be written in to the disk*/
	size_t block_count = (bytes_written / BLOCK_SIZE) + 1;
	if (bytes_written % BLOCK_SIZE == 0)
	{
		block_count--;
	}

	/* Buffer blocks used to store the data to be written */
	uint8_t buffer_blocks[block_count * BLOCK_SIZE];
	int remaining_bytes = bytes_written;
	size_t blocks_written = 0;
	uint8_t temp_block[BLOCK_SIZE];
	size_t next_empty_block = find_first_empty_block(0);
	int size_change = 0;
	if (space_in_last_block)
	{
		/* If there is space in the file's last block, then read that block first
		then copy data @buf into the buffer block */
		if (!empty_file)
		{
			size_t frist_written_bytes;
			if (bytes_written > space_in_last_block)
			{
				frist_written_bytes = space_in_last_block;
			}
			else
			{
				frist_written_bytes = bytes_written;
			}
			/* Copy the last block and write onto it */
			block_read(current_FAT_index + m_data.s_block.DB_start_index,
					   &buffer_blocks[0]);
			memcpy(&buffer_blocks[offset], buf, bytes_written);
			memcpy(&temp_block, &(buffer_blocks[blocks_written * BLOCK_SIZE]), BLOCK_SIZE);
			/* Write the modified block onto disk */
			block_write(current_FAT_index + m_data.s_block.DB_start_index, &temp_block);
			blocks_written++;
			size_change = size_diff(fd, frist_written_bytes);
			update_fd(fd, frist_written_bytes, size_change);
			remaining_bytes -= frist_written_bytes;
			if (remaining_bytes != 0)
			{
				next_empty_block = find_first_empty_block(current_FAT_index);
			}
		}
		else
		{
			memcpy(&buffer_blocks[0], buf, bytes_written);
		}
	}
	else
	{
		memcpy(&buffer_blocks[0], buf, bytes_written);
		current_FAT_index = find_first_empty_block(current_FAT_index);
	}

	while (remaining_bytes > 0)
	{
		if (current_FAT_index != FAT_EOC)
		{
			m_data.FAT[current_FAT_index] = next_empty_block;
		}
		current_FAT_index = next_empty_block;
		m_data.FAT[current_FAT_index] = FAT_EOC;
		memcpy(&temp_block, &(buffer_blocks[blocks_written * BLOCK_SIZE]), BLOCK_SIZE);
		block_write(current_FAT_index + m_data.s_block.DB_start_index, &temp_block);
		blocks_written++;
		next_empty_block = find_first_empty_block(current_FAT_index);
		size_change = size_diff(fd, BLOCK_SIZE);
		if (remaining_bytes < BLOCK_SIZE)
		{
			size_change = size_diff(fd, remaining_bytes);
		}
		update_fd(fd, size_change, size_change);
		remaining_bytes -= BLOCK_SIZE;
	}
	update_RD(fd);
	return bytes_written;
}

int fs_read(int fd, void *buf, size_t count)
{
	if (!m_data.mounted)
	{
		return -1;
	}

	if (fd < 0 || fd >= MAX_DES)
	{
		return -1;
	}

	if (!buf)
	{
		return -1;
	}

	//calculate the number of bytes can be read
	size_t remaining_bytes = descriptors[fd].size - descriptors[fd].inc;

	//calculate actual number of bytes will be read
	size_t bytes_read = count;
	if (remaining_bytes <= count)
	{
		bytes_read = remaining_bytes;
	}

	// get the start index to read with current offset
	size_t skip_count = blocks_to_skip(fd);

	// nubmer of blocks to be read
	size_t read_block_count = (bytes_read / BLOCK_SIZE) + 1;

	// calculate the number of bytes can be read in the current block
	size_t bytes_in_first_block = BLOCK_SIZE - (descriptors[fd].inc % BLOCK_SIZE);
	if (descriptors[fd].inc == 0)
	{
		bytes_in_first_block = 0;
	}
	if (bytes_read % BLOCK_SIZE == 0)
	{
		read_block_count--;
	}
	if (bytes_in_first_block < bytes_read && bytes_in_first_block != 0)
	{
		read_block_count++;
	}

	// buffer for reading in needed blocks
	int8_t buffer_blocks[read_block_count * BLOCK_SIZE];

	// get the first index to start in FAT and DB
	size_t current_FAT_index = descriptors[fd].file.index;

	for (size_t i = 0; i < skip_count; i++)
	{
		current_FAT_index = m_data.FAT[current_FAT_index];
	}

	uint8_t temp_block[BLOCK_SIZE];
	for (size_t i = 0; i < read_block_count; i++)
	{
		block_read(current_FAT_index + m_data.s_block.DB_start_index, &temp_block);
		memcpy(&buffer_blocks[i * BLOCK_SIZE], &temp_block, BLOCK_SIZE);
		current_FAT_index = m_data.FAT[current_FAT_index];
	}
	memcpy(buf, &buffer_blocks[descriptors[fd].inc - (skip_count * BLOCK_SIZE)], bytes_read);
	descriptors[fd].inc += bytes_read;

	return bytes_read;
}

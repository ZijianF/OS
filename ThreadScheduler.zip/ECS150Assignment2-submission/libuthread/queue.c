#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "queue.h"

struct queue
{
	/* TODO */
	int size;
	void ***data;
};

queue_t queue_create(void)
{
	/* TODO */
	queue_t new_queue = (queue_t)calloc(1, sizeof(struct queue));
	if (!new_queue)
	{
		return NULL;
	}
	new_queue->size = 0;
	return new_queue;
}

int queue_destroy(queue_t queue)
{
	/* TODO */
	if (queue == NULL)
	{
		return -1;
	}
	if (queue->size != 0)
	{
		return -1;
	}

	for (int i = 0; i < queue->size; i++)
	{
		free(*queue->data[i]);
	}
	free(queue);
	queue = NULL;
	return 0;
}

int queue_enqueue(queue_t queue, void *data)
{
	/* TODO */
	if (queue == NULL)
	{
		return -1;
	}
	if (data == NULL)
	{
		return -1;
	}
	queue->size++;
	// printf("test3 %d\n", queue->size);
	queue->data = realloc(queue->data, queue->size * sizeof(void **));
	if (!queue->data)
	{
		return -1;
	}
	queue->data[queue->size - 1] = data;
	return 0;
}

int queue_dequeue(queue_t queue, void **data)
{
	/* TODO */
	// printf("test8 %d\n", queue->size);
	if (queue == NULL)
	{
		return -1;
	}
	if (data == NULL)
	{
		return -1;
	}
	if (queue->size == 0)
	{
		return -1;
	}
	// printf("test8 %d\n", queue->size);
	//printf("test2 %p\n", queue->data[0]);
	*data = (queue->data[0]);
	//printf("test3 %p\n", data);
	for (int i = 0; i < queue->size - 1; i++)
	{
		queue->data[i] = queue->data[i + 1];
	}
	// printf("test3 %d\n", queue->size);
	queue->size--;
	// printf("test3 %d\n", queue->size);
	queue->data = realloc(queue->data, queue->size * sizeof(void *));
	// printf("test4 \n");

	return 0;
}

int queue_delete(queue_t queue, void *data)
{
	/* TODO */
	//int d = (int)*data;

	if (queue == NULL)
	{

		return -1;
	}
	if (data == NULL)
	{

		return -1;
	}
	// printf("%ld\n", (long)data);
	// printf("%ld\n", (long)queue->data[1]);
	for (int i = 0; i < queue->size; i++)
	{
		// printf("hello %ld\n", (long)data);
		// printf("%ld\n", (long)queue->data[i]);

		if (data == (queue->data[i]))
		{
			// printf("core duuuuuuuuuuuuuuuuuuuumped\n");
			for (int j = i; j < queue->size - 1; j++)
			{
				queue->data[j] = queue->data[j + 1];
			}
			queue->size--;
			queue->data = realloc(queue->data, queue->size * sizeof(void *));
			return 0;
		}
	}
	//printf("del not found \n");
	return -1;
}

int queue_iterate(queue_t queue, queue_func_t func, void *arg, void **data)
{
	/* TODO */
	if (queue == NULL)
	{
		return -1;
	}
	if (func == NULL)
	{
		return -1;
	}
	for (int i = -1; i < queue->size - 1; i++)
	{
		int cur_size = queue->size;
		if (func(queue, queue->data[i + 1], arg))
		{
			if (data)
			{
				*data = (queue->data[i + 1]);
			}
			return 1;
		}
		i = i - (cur_size - queue->size);
		continue;
	}
	return 0;
}

int queue_length(queue_t queue)
{
	/* TODO */
	if (queue == NULL)
	{
		return -1;
	}
	return queue->size;
	return 0;
}

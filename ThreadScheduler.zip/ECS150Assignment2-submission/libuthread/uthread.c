#include <assert.h>
#include <limits.h>
#include <signal.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include "private.h"
#include "uthread.h"
#include "queue.h"

#define REG_AMT 32
#define REG_SIZE 256 //bytesize for 32 registers in 64-bit system
#define UTHREAD_STACK_SIZE 3276
#define READY 0
#define RUN 1
#define BLOCK 2
#define ZOMBIE 3

#define J 1
#define NJ 0

#define T 1
#define F 0

/* TODO */
typedef struct TCB
{
	uthread_t TID;
	int state;
	void *stack;
	uthread_ctx_t *uctx;
	uthread_func_t func;
	queue_t tasks;			//threads that are joined by this TID
	uthread_t current_task; // == TID when it is running own its own ,!= when switched
	int task_size;

} TCB;

typedef struct TCB *TCBP;
TCBP mainthread;
uthread_t gtid; //global tid

//for storing block's content by storing pointer
queue_t TCBP_pool;
//for tracking block's address
//queue_t TCBP_pool;

//public retval
int ret;
TCBP current_thread;
TCBP to_delete_thread;

int pre = F;

queue_t zombie_land; //finished and ready to be collected

queue_t wait_land;

//free:uctx, stack, tasks
void free_TCB(TCBP tcbp)
{

	free(tcbp->uctx);
	uthread_ctx_destroy_stack(tcbp->stack);
	queue_destroy(tcbp->tasks);
	free(tcbp);
}

void free_resource(void)
{
	int pool_size;
	pool_size = queue_length(TCBP_pool);
	for (int i = 0; i < pool_size; i++)
	{
		TCBP pooler;
		queue_dequeue(TCBP_pool, (void **)&pooler);
		free_TCB(pooler);
	}

	queue_destroy(TCBP_pool);

	free_TCB(current_thread);
	//	delete zombie land
	int zombie_count;
	zombie_count = queue_length(zombie_land);
	for (int i = 0; i < zombie_count; i++)
	{
		TCBP zombie;
		queue_dequeue(zombie_land, (void **)&zombie);
		free_TCB(zombie);
	}
	queue_destroy(zombie_land);
	int wait_count;
	wait_count = queue_length(wait_land);
	for (int i = 0; i < wait_count; i++)
	{
		TCBP wait;
		queue_dequeue(wait_land, (void **)&wait);
		free_TCB(wait);
	}
	queue_destroy(wait_land);
}

TCBP ini_thread(TCBP t, uthread_func_t func)
{
	//shoud have sequential tid
	preempt_disable();
	t = calloc(1, sizeof(struct TCB));
	t->TID = gtid;
	gtid++;
	t->state = READY; //main() already running
	t->stack = uthread_ctx_alloc_stack();
	//uctx:context pointer, stack pointer, function to call when called swap
	t->uctx = calloc(1, sizeof(uthread_ctx_t));
	t->tasks = queue_create();
	t->current_task = t->TID;
	t->task_size = 0;
	t->func = func;
	//set up dummy context for later swap when context will be saved
	uthread_ctx_init(t->uctx, t->stack, func);
	preempt_enable();
	return t;
}

static int find_thread_callee(queue_t q, void *data, void *arg)
{
	//arg is current_thread;
	//data is the address of thread to be compared in queue
	TCBP index;
	index = (TCBP)data;
	//arg is current thread(caller);
	TCBP curr_thd = (TCBP)(arg);
	(void)q;
	if (curr_thd->current_task == index->TID)
		return 1;
	return 0;
}

static int find_thread_caller(queue_t q, void *data, void *arg)
{
	//arg is current_thread;
	//data is the address of thread to be compared in queue
	TCBP index;
	index = (TCBP)data;
	//arg is current thread (callee);
	TCBP curr_thd = (TCBP)(arg);
	(void)q;
	//A self running task is also in
	if (curr_thd->TID == index->current_task && index->current_task != index->TID)

		return 1;
	return 0;
}

static int find_task(queue_t q, void *data, void *arg)
{

	uthread_t *index;
	index = (uthread_t *)data;
	//arg is current thread (callee);
	uthread_t *tid_to_find = (uthread_t *)(arg);
	(void)q;
	if (*index == *tid_to_find)
		return 1;
	return 0;
}

//NULL, 0 will print all the Threads in pool
void pth(TCBP thd, uthread_t tid)
{
	if (thd != NULL)
	{
		printf("\nTID %hu", thd->TID);
		printf("state: %d", thd->state);
		printf("task size %d\n", thd->task_size);
		int ats = queue_length(thd->tasks);
		printf("actual task size %d\n", ats);
		printf("current_task: %hu\n", thd->current_task);

		uthread_t *tid;
		for (int i = 0; i < ats; i++)
		{
			queue_dequeue(thd->tasks, (void **)&tid);
			printf("task ID: %hu \n\n", thd->current_task);
			queue_enqueue(thd->tasks, (void *)tid);
		}
	}
	else
	{
		if (tid == 0)
		{

			TCBP print_tid;

			printf("c:->\n");
			pth(current_thread, 0);
			printf("pool:-->\n");
			int pool_size = queue_length(TCBP_pool);
			for (int i = 0; i < pool_size; i++)
			{
				queue_dequeue(TCBP_pool, (void **)&print_tid);
				pth(print_tid, 0);
				queue_enqueue(TCBP_pool, (void *)print_tid);
			}
			printf("zombie land:-->\n");
			int zombie_count = queue_length(zombie_land);
			for (int i = 0; i < zombie_count; i++)
			{
				queue_dequeue(zombie_land, (void **)&print_tid);
				pth(print_tid, 0);
				queue_enqueue(zombie_land, (void *)print_tid);
			}
			printf("wait land:--------->\n");
			int wait_count = queue_length(wait_land);
			for (int i = 0; i < wait_count; i++)
			{
				queue_dequeue(wait_land, (void **)&print_tid);
				pth(print_tid, 0);
				queue_enqueue(wait_land, (void *)print_tid);
			}
		}
		else
		{
			TCBP print_tid = NULL;
			if (1 == queue_iterate(TCBP_pool, find_task, &tid, (void **)print_tid))
			{
				printf("\nTID %hu", print_tid->TID);
				printf("state: %d", print_tid->state);
				printf("task size %d\n", print_tid->task_size);
				int ats = queue_length(print_tid->tasks);
				printf("actual task size %d\n", ats);
				uthread_t *tid;
				for (int i = 0; i < ats; i++)
				{
					queue_dequeue(print_tid->tasks, (void **)&tid);
					printf("task ID: %hu \n", print_tid->current_task);
					queue_enqueue(print_tid->tasks, (void *)tid);
				}
			}
		}
	}
}
//not actually delete but put back to the end of tasks
int delete_task(TCBP thd, uthread_t tid)
{
	uthread_t *tid_to_delete;
	int del_op = queue_iterate(thd->tasks, find_task, &tid, (void **)&tid_to_delete);
	queue_delete(thd->tasks, tid_to_delete);
	thd->task_size -= 1;
	//push back to become zombie
	queue_enqueue(thd->tasks, tid_to_delete);
	return del_op;
}
void add_task(TCBP thd, uthread_t tid)
{
	queue_enqueue(thd->tasks, &tid);
	thd->task_size += 1;
}

//zombie children collector
//destory individual data structure
//delete them from TCBP_pool
int uthread_collect_joined(TCBP ct)
{
	///	int collect = 1;
	if (ct->current_task == ct->TID)
	{
		//should not be here
		return -1;
	}

	TCBP to_delete;
	///int find = 0;
	queue_iterate(TCBP_pool, find_thread_callee, ct, (void **)&to_delete);
	if (to_delete->state != ZOMBIE)
	{
		return 0;
	}
	//current task is fouind and its a zombie

	queue_delete(TCBP_pool, to_delete);
	//freeing the children only
	free_TCB(to_delete);
	ct->current_task = ct->TID;
	return 1;
}

//push a new thread to ready queue
int uthread_start(int preempt)
{
	/* TODO */
	pre = preempt;
	if (pre == T)
	{
		preempt_start();
		preempt_enable();
	}

	//create Main thread
	mainthread = ini_thread(mainthread, 0);
	mainthread->state = RUN;
	//set up the thread queue for scheduling
	TCBP_pool = queue_create();
	zombie_land = queue_create();
	wait_land = queue_create();

	current_thread = mainthread;

	return 0;
}

//collect the  zombie children and kill it self
int uthread_stop(void)
{
	/* TODO */
	//free the other threads
	//might need to change to a better indicator
	if (pre == T)
	{
		preempt_disable();
		preempt_stop();
		//printf("preempted\n");
	}
	//collect tasks for main thread
	int collect;
	collect = uthread_collect_joined(current_thread);
	if (collect != 1)
	{
	}

	if (current_thread->TID != 0)
	{
		fprintf(stderr, "stop before main\n");
		free_resource();
		return -1;
	}
	//these should not go before the first if statement
	free_resource();
	gtid = 0;
	return 0;
}

//initialize the a thread with context init
//stack inint and a func thats ready to run
//while the joining thread is still running after this
//until a yield
int uthread_create(uthread_func_t func)
{
	/* TODO */
	//create a ready context using makecontext
	if ((int)gtid + 1 > UTHREAD_STACK_SIZE)
	{
		fprintf(stderr, "cannot add more thread \n");
		return -1;
	}

	//create a new thread with ready to be changed	context
	TCBP new_thread = NULL;
	new_thread = ini_thread(new_thread, func);
	//new thread is deployed
	queue_enqueue(TCBP_pool, new_thread);

	//current thread is tasked with waiting / jonining a new thread
	//!!! this cpy need to be found and delete and free by delete_task
	add_task(current_thread, new_thread->TID);

	return new_thread->TID;
}

//save the current thread's context and switch to the next thread{ready or blocked}
//del marked for whether it will collect itself
//s marked for whether there will be a collector emplace and collect
//if pre is on a waiting thread will be pushed
void uthread_yield_with_state(int s, int del)
{
	if (pre == T)
	{
		preempt_disable();
	}
	current_thread->state = s;
	//switch_state should no be zombie;
	int switch_state;

	TCBP tmp_current_holder = current_thread;
	TCBP switch_thread;
	///int exit_found;
	if (s == ZOMBIE && del == F)
	{
		//switch thread is joining thread now
		//emplace back from wait_land and find the next state
		queue_iterate(wait_land, find_thread_caller,
					  current_thread, (void **)&switch_thread);
		queue_delete(wait_land, switch_thread);
		queue_enqueue(TCBP_pool, switch_thread);
	}
	if (del == T && s == ZOMBIE)
	{
		queue_enqueue(zombie_land, tmp_current_holder);
		//switch to next in ready queue
	}
	//Block , ZOMBIE+del , ZOMBIE
	int found = F;
	int pool_size;
replace: // happens when ready queue is empty
	pool_size = queue_length(TCBP_pool);
	for (int pool_index = 0; pool_index < pool_size; pool_index++)
	{
		queue_dequeue(TCBP_pool, (void **)&switch_thread);

		//skip the zombie state
		switch_state = switch_thread->state;
		if (switch_state == ZOMBIE)
		{
			queue_enqueue(TCBP_pool, (void *)switch_thread);
			continue;
		}
		else
		{
			//same for (switch_state == BLOCK || switch_state == READY)
			switch_thread->state = RUN;
			if (del != T) //Block
				queue_enqueue(TCBP_pool, tmp_current_holder);
			current_thread = switch_thread;
			found = T;
			break;
		}
	}

	//special case of yield when nothing to yield to
	if (found == F && pool_size != 0)
	{
		//no thread to yield to  pop
		//it is not possible that a reentered thread-
		//is joining for the current thread
		queue_dequeue(wait_land, (void **)&switch_thread);
		queue_enqueue(TCBP_pool, switch_thread);
		goto replace;
	}

	if (pre == T)
	{
		preempt_enable();
	}
	uthread_ctx_switch(tmp_current_holder->uctx, current_thread->uctx);
	// psych! yield switched back

	//proceed to exit the yield function and continue with the context
	//restored by uthread_exit
	return;
}

//A thread is yielded to
void uthread_yield(void)
{
	uthread_yield_with_state(BLOCK, F);
}

//these threads will stay for ever untilcollected by joining thread
void uthread_exit_to_next(void)
{
	//This only switch to the next available thread
	//wait for its caller to retrieve
	uthread_yield_with_state(ZOMBIE, F);
}

//An innocent thread finished it is yielded not joined to
//should mark zombie
void uthread_exit_to_next_and_clean()
{
	uthread_yield_with_state(ZOMBIE, T);
}

uthread_t uthread_self(void)
{
	return current_thread->TID;
}

//switch back to current thread's caller
//a leaf thread or a thread with all it's task done will  exit here
//returned from context.c- uthread_ctx_bootstrap
void uthread_exit(int retval)
{
	//Find the caller of current thread
	//until the thread quit
	// thread needs to hold on to the return value
	//to make the return modified retrieved within order
	TCBP switch_thread;
	int exit_found = queue_iterate(wait_land, find_thread_caller,
								   current_thread, (void **)&switch_thread);
	if (exit_found == 1)
	{
		//a joined-to thread
		//printf("exitfound\n");
		current_thread->state = ZOMBIE;

		ret = retval;
		uthread_exit_to_next();
	}
	else if (exit_found != 1 && exit_found != -1)
	{
		//exiting this thread should be a yield to another thread
		// clean itself

		//no wait(joining ) the retval is irrelevant
		uthread_exit_to_next_and_clean();
	}
}

//wait the tid to finish(including it's tids)
//if a  child tcb is finished parent need to collect it from  ready queue
//upon the parent gets control

int uthread_join(uthread_t tid, int *retval)
{
	//each thread can only be joined once
	if (pre == T)
	{
		preempt_disable();
	}
	//a thread can only be joined once
	/* TODO */
	if (tid == 0)
	{
		fprintf(stderr, "cannot join main thread\n");
		return -1;
	}
	else if (tid == current_thread->TID)
	{

		fprintf(stderr, "cannot join thread itself\n");
		return -1;
	}

	//delete find
	//queue_dequeue(current_thread->tasks, (void **)&todo);

	current_thread->current_task = tid;
	///uthread_t tmp_tid;
	//print_thread(current_thread);
	//int del;
	// if queue_iterate(find ) succedded then del == 1
	delete_task(current_thread, (current_thread->current_task));
	//printf("del:%d\n", del);
	//print_thread(current_thread);

	TCBP switch_thread;
	//printf("switch_thread-> tastk %hu\n", tid);
	int find = 0;
	find = queue_iterate(TCBP_pool, find_thread_callee, current_thread, (void **)&switch_thread);
	if (find == 0)
	{
		fprintf(stderr, "cannot find thread \n");
		return -1;
	}
	//thread found and available;
	//put current thread for later returning

	//the current will be replaced with poped switch_thread thus queue needs to be deleted
	queue_delete(TCBP_pool, switch_thread);

	//find the task TCB in Pool and switch to it from current;
	TCBP tmp_current_holder = current_thread;
	tmp_current_holder->state = BLOCK;
	tmp_current_holder->current_task = tid;
	current_thread = switch_thread;
	current_thread->state = RUN;

	//switching to new thread will freeze current_thread
	//push to wait_land
	queue_enqueue(wait_land, tmp_current_holder);
	if (pre == T)
	{
		preempt_enable();
	}
	uthread_ctx_switch(tmp_current_holder->uctx, switch_thread->uctx);
	uthread_collect_joined(tmp_current_holder);

	//Psych! should now be switch back to current_thread by uthread_exit

	//collect collectable children
	//if not yield

	//Wait ended , put retval
	if (retval)
		*retval = ret;
	return 0;
}
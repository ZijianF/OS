#include <signal.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

#include "private.h"
#include "uthread.h"

/*
 * Frequency of preemption
 * 100Hz is 100 times per second
 */
#define HZ 100

/* Global varaibles  */
struct sigaction new_sa, old_sa;
struct itimerval timer, old_timer;
sigset_t ss;

/*Define a signal handler to yield the current thread*/
void handler_yield_thread()
{

	uthread_yield();
}

void preempt_start(void)
{
	// Set up the new signal handler /
	new_sa.sa_handler = handler_yield_thread;
	sigemptyset(&new_sa.sa_mask);
	new_sa.sa_flags = 0;
	sigaction(SIGVTALRM, &new_sa, &old_sa);
	//Configure the timer to expireafter 1/100 second
	//1 second = 1000000 micro seconds;
	long int seconds = 1000000 / HZ;
	timer.it_value.tv_sec = 0;
	timer.it_value.tv_usec = seconds;

	// Configure the timer to expire after 1/100 second
	//after first expiration
	timer.it_interval.tv_sec = 0;
	timer.it_interval.tv_usec = seconds;
	setitimer(ITIMER_VIRTUAL, &timer, &old_timer);
}

void preempt_stop(void)
{
	/* Restore the previous timer configuration and signal action*/
	setitimer(ITIMER_VIRTUAL, &old_timer, NULL);
	sigaction(SIGVTALRM, &old_sa, NULL);
}

void preempt_enable(void)
{
	sigemptyset(&ss);
	sigaddset(&ss, SIGVTALRM);
	sigprocmask(SIG_UNBLOCK, &ss, NULL);
}

void preempt_disable(void)
{
	sigemptyset(&ss);
	sigaddset(&ss, SIGVTALRM);
	sigprocmask(SIG_BLOCK, &ss, NULL);
}

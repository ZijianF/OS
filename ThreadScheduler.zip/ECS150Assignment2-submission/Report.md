# A User-level thread library

---

## 1.Queue Implementation

---
        The queue API is implemented in the similary logic as most 
    common queue implementations. One point that is worth of mentioning
    is when creating a queue struct, the actually queue is represented
    in the type of a void***. Which is a array of void**. Because void**
    can store the address of a pointer. Doing so enables the queue to
    take all kinds of data as long as it is pointed by a pointer.
---

## 1.1 Testing queue

---
        Queue is tested in a unit test fashion. Starting with testing each
    individual functions's functionality to make sure that do their own job.
    Then make tests that combine these functions to make sure the queue
    behaves correctly when given multiple different instructions.
        We also tested the queue's flexibility by giving it different types
    of data.
        Also, the queue, in its own managebale range, makes sure there
    is no memory leak. Data that are dequeued and deleted will not have 
    their memory block freed because it is the user's option. When 
    queue_destroy() is called at the right time(when queue is empty),
    there will be no memery leak. 
        We did not test error management for every single function because
    they share the logic when handling errors. So testing some of them is 
    sufficent for testing errors managements.
---

## 2.User thread API Choices

---
         For this part, there are essentially 4 containers to consider: 
    1. TCBP_pool,the ready queue.
    2. current_thread, the current_thread.
    3. a  zombie_land, where the finished threads are placed for final
        memory collection.
    4.and wait_land, a special queue for joining threads.  

       
         Each of the 3 containers but current_thread is a queue_t type queue,
    which can not  only stores the TCBs but also their sequence. This 
    behavior lets thethread run in a  cascade falling  mannar.
        
        The choice of the zombie_land lets the main ready queue run smaller
    loops when we are removing and enqueuing. It is  a good safe  on time,
    and it shares the same freeing code pattern as the other queues.

        When it comes to the trailing function uthread_join, it is saved to 
    the wait_queue because  wait_queue is a necessary placement to give
    a clear ready-and-run  logic to the main queue, and it also help reduce 
    the size of main queue.

---

## 3. Preemtion

---
        When preemption is enabled, it will install a new signal handler
    to handle SIGVTALRM. At the same time, the old method of handling this
    kind of handling this kind of signal need to be saved. Same thing applies
    to setting up a new timer to send SIGVTALRM at 100HZ. To achieve the
    the ability to store the information, global values:
        struct sigaction new_sa, old_sa;
        struct itimerval timer, old_timer;
    They are kept at the global scope. They are for the function preempt_stop()
    to access when trying to restore the previous settings.
    preempt_enable and preempt_disable simply unblock or block SIGVTALRM.
---

## 4. Preemption Testing

---
        Out Preemption test is modified from thread_yield.c. This test
    program also only makes thread 0 (main) create and join thread 1.
    Thread 1 creates thread 2 and joins it, thread 2 creates thread 3
    and joins it.
        To test if preemption works properly, we seted up some global
    variables that all functions can access. And make thread 1 go into
    a infinite loop if it does not yield by preemption.
        We use infinite loop here because we want makes sure this
    test program is valid on different machine with different
    performance. These loops makes sure that there will be enough time
    for the timer to fire a signal.
        Similar logic applies to thread 2 and thread 3. They all rely
    on another thread to change the global variables' value to exit 
    the "infinite" loop. This program will not be properly executed 
    if preemption does not work properly. When calling TEST_ASSERT,
    the values being checked are not so important. But the fact that
    all three threads are able to finish their execution means that
    preemption works as how we want it to.
        The test program will keep printing fail# during the the loops,
    for some reason, if we disable the printf() in the program, it will
    not work properly. But the result shows that preemption works properly.

/*
 * Thread creation and yielding test
 *
 * Tests the creation of multiples threads and the fact that a parent thread
 * should get returned to before its child is executed. The way the printing,
 * thread creation and yielding is done, the program should output:
 *
 * thread1
 * thread2
 * thread3
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <uthread.h>
#define TEST_ASSERT_YIELD(assert)           \
	do                                      \
	{                                       \
		printf("ASSERT: " #assert " ... "); \
		if (assert)                         \
		{                                   \
			printf("PASS\n");               \
		}                                   \
		else                                \
		{                                   \
			printf("FAIL\n");               \
			exit(1);                        \
		}                                   \
	} while (0)

int thread3(void)
{
	uthread_yield(); //4  // 2 1 0 3
	printf("thread3: %d\n", uthread_self());
	return 0;
}

int thread2(void)
{
	uthread_create(thread3); // 2 1 0 + 3
	uthread_yield();		 //2		 //1 0 3 2
	printf("thread2 :%d\n", uthread_self());
	return 0; // 2 1 0 3
}

int thread1(void)
{
	uthread_create(thread2); // 1 0  2
	uthread_yield();		 //1	 // 0 ! 2 1 - > 2 1 0 /////2 0 1
	//for (int i = 0; i < 3; i++)
	//{
	//	sleep(1);
	//	printf("sleeped 1s\n");
	//}
	//while (0)
	//{
	//};
	printf("thread1 :%d\n", uthread_self());
	uthread_yield(); //3  //1 ! 0 3 2 -> 3 2 1 0
	return 0;		 //2103 -> 1 0 3 ->
}

//nested joining
int thread4(void)
{
	uthread_join(uthread_create(thread1), NULL);
	return 0;
}

int thread5(void)
{
	return 0;
}
int main(void)
{
	uthread_start(0);
	uthread_join(uthread_create(thread1), NULL); //->0 3
	//nested joining
	//uthread_join(uthread_create(thread4), NULL);
	//
	uthread_stop();

	uthread_start(0);
	//regular thread join
	printf("none \n");
	uthread_yield();
	uthread_stop();

	uthread_start(0);
	//nested joining

	printf("nested: 2 3 4\n");
	uthread_join(uthread_create(thread4), NULL);
	uthread_stop();

	return 0;
}

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

#include <queue.h>

#define TEST_ASSERT(assert)				\
do {									\
	printf("ASSERT: " #assert " ... ");	\
	if (assert) {						\
		printf("PASS\n");				\
	} else	{							\
		printf("FAIL\n");				\
		exit(1);						\
	}									\
} while(0)

/* Create */
void test_create(void)
{
	fprintf(stderr, "*** TEST create ***\n");

	TEST_ASSERT(queue_create() != NULL);
}

/* Enqueue/Dequeue simple */
void test_queue_simple(void)
{
	int data = 3, *ptr;
	queue_t q;

	fprintf(stderr, "*** TEST queue_simple ***\n");
	// printf("test0 %p\n", &data);
	q = queue_create();	
	queue_enqueue(q, &data);
	queue_dequeue(q, (void**)&ptr);
	//printf("test %d", *ptr);
	
	TEST_ASSERT(ptr == &data);
}

/* enqueue/dequeue/change of length */
void test_length(void)
{
	int data = 3, *ptr;
	queue_t q;

	fprintf(stderr, "*** TEST length_simple ***\n");
	// printf("test0 %p\n", &data);
	q = queue_create();	
	
	queue_enqueue(q, &data);
	
	queue_enqueue(q, &data);
	
	queue_enqueue(q, &data);
	queue_enqueue(q, &data);
	// printf("test7 %d\n", queue_length(q));
	queue_dequeue(q, (void**)&ptr);	
	
	int count = queue_length(q);
	TEST_ASSERT(count == 3);
}



void test_delete(void)
{
	int data1 = 1, data2 = 2, data3 = 3, *ptr;
	queue_t q;
	// printf("test %p\n", &data3);
	fprintf(stderr, "*** TEST Delete ***\n");
	// printf("test0 %p\n", &data);
	q = queue_create();	
	queue_enqueue(q, &data1);
	queue_enqueue(q, &data2);
	queue_enqueue(q, &data3);
	queue_delete(q, &data2);
	queue_dequeue(q, (void**)&ptr);	
	queue_dequeue(q, (void**)&ptr);	
	// printf("test %p\n", ptr);
	TEST_ASSERT(ptr == &data3);
}

static int inc_item(queue_t q, void *data, void *arg)
{
    int *a = (int*)data;
    int inc = (int)(long)arg;
	
    if (*a == 1){
		// printf("test func here\n");
        queue_delete(q, data);
	}
    else{
		// printf("test func here1\n");
		*a += inc;
	}

    return 0;
}

static int find_item(queue_t q, void *data, void *arg)
{
    int *a = (int*)data;
    int match = (int)(long)arg;
    (void)q; //unused

    if (*a == match)
        return 1;

    return 0;
}

void test_func(void)
{
	int data1 = 1, data2 = 2, data3 = 3, *ptr;
	queue_t q;
	printf("test %p\n", &data3);
	fprintf(stderr, "*** TEST Function ***\n");
	// printf("test0 %p\n", &data);
	q = queue_create();	
	queue_enqueue(q, &data1);
	queue_enqueue(q, &data2);
	queue_enqueue(q, &data3);
	queue_iterate(q, inc_item, (void*)1, NULL);
	queue_dequeue(q, (void**)&ptr);	
	//queue_dequeue(q, (void**)&ptr);	
	printf("test %d\n", (int)*ptr);
	TEST_ASSERT(*ptr == 3);
}

void test_func_find_item(void)
{
	int data1 = 1, data2 = 2, data3 = 3, *ptr;
	queue_t q;
	printf("test %p\n", &data3);
	fprintf(stderr, "*** TEST Function find item ***\n");
	// printf("test0 %p\n", &data);
	q = queue_create();	
	queue_enqueue(q, &data1);
	queue_enqueue(q, &data2);
	queue_enqueue(q, &data3);
	queue_iterate(q, find_item, (void*)3, (void**)&ptr);
	TEST_ASSERT(*ptr == 3);
}


// void test_destroy(void)
// {
// 	// int data1 = 1, data2 = 2, data3 = 3;
// 	queue_t q;
// 	// printf("test %p\n", &data3);
// 	// fprintf(stderr, "*** TEST Destroy ***\n");
// 	// // printf("test0 %p\n", &data);
// 	q = queue_create();	
// 	// queue_enqueue(q, &data1);
// 	// queue_enqueue(q, &data2);
// 	// queue_enqueue(q, &data3);
// 	// queue_destroy(q);
// 	printf("test0 %p\n", q);
// 	free(q);
// 	printf("test0 %p\n", q);
// 	TEST_ASSERT(q);
// }



/*Error tests start here*/

void test_null1(void)
{
	/*One test is sufficent for all functions,
	sicne they are implmented with the same logic*/
	int data1 = 1;
	queue_t q;
	fprintf(stderr, "*** TEST WHEN Q IS NULL ***\n");
	q = NULL;
	int test = queue_enqueue(q, &data1);
	TEST_ASSERT(test == -1);
}

//some more tests might be needed. 
/*Error tests end here*/

/*comlicated tests start here*/

/*comlicated tests end here*/

int main(void)
{
	test_create();
	test_queue_simple();
	test_length();
	test_delete();
	test_func();
	test_func_find_item();
	// test_destroy();
	
	test_null1();
	return 0;
}

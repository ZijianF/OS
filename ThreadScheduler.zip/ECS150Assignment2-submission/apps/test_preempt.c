#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <private.h>
#include <queue.h>

#define TEST_ASSERT(assert)                 \
    do                                      \
    {                                       \
        printf("ASSERT: " #assert " ... "); \
        if (assert)                         \
        {                                   \
            printf("PASS\n");               \
        }                                   \
        else                                \
        {                                   \
            printf("FAIL\n");               \
            exit(1);                        \
        }                                   \
    } while (0)
int b = 0;
int a = 0;
int thread3(void)
{

    //    uthread_yield();
    //*3 2 (1 0)
    (b)++;
    while (b == 1)
    { //wait for prem *2 3 (1 0)

        printf("FAIL3\n");
    } // break * 3 (2 1 0)
    fprintf(stderr, "*** TEST 3 ***\n");
    printf("thread%d %d\n", uthread_self(), b);
    TEST_ASSERT(b == 2);
    return 0; // 3 terminates *2 (1 0)
}

int thread2(void)
{
    //uthread_yield();
    int t3 = uthread_create(thread3); // *2 1 3
    a++;                              // *a = 1;
    while (b == 0)
    { //first prm *1 3 2

        printf("FAIL 2\n");
    }    // loop break *2 3 (1 0)
    b++; //b = 2
    fprintf(stderr, "*** TEST 2***\n");
    //printf("thread%d %d\n", uthread_self(), *a);
    TEST_ASSERT(b == 2);

    uthread_join(t3, NULL); // *3 (2 1 0)
    return 0;               // 2 terminates *1 (0)
}

int thread1(void)
{

    int t2 = uthread_create(thread2); // *1 2
    while (a == 0)
    { //1st prm: *2 1
        printf("FAIL1\n");
    } // out of loop: *1 3 2
    fprintf(stderr, "*** TEST 1***\n");
    TEST_ASSERT(a == 1);
    uthread_join(t2, NULL); //a waits for 2 to join *3 2 (1 0)
    return 0;               //a finishes *0
}

int main(void)
{
    uthread_start(1);
    uthread_join(uthread_create(thread1), NULL);
    uthread_stop();
}
